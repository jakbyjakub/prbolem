
#include "klasa2.h"
#include<iostream>
#include "podgra.h"



using namespace std;
void p1::wyb11()
{
	podgra::animacjaladowania();
	
	cout << "a";

}


void p2::wyb12()
{

	
	cout << "a";
}
void p3::wyb13()
{
	
	
	cout << "a";
}
