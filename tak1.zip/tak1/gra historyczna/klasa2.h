#pragma once 
#include "klasa2.h"
#include "podgra.h"

class p1 :public podgra
{
public:

	void wyb11();

};

class p2 
{
public:
	void wyb12();

};



class p3 
{
public:
	void wyb13();

};




